package fr.univrennes1.istic.wikipediamatrix;

import java.util.List;

public class RetourTraiterUnSeulHeader {

	private List<String> listeHeaders;
	private List<Integer> positionsRowspans;

	public RetourTraiterUnSeulHeader(List<String> listeHeaders, List<Integer> positionsRowspans) {
		this.listeHeaders = listeHeaders;
		this.positionsRowspans = positionsRowspans;
	}

	public List<String> getListeHeaders() {
		return listeHeaders;
	}

	public void setListeHeaders(List<String> listeHeaders) {
		this.listeHeaders = listeHeaders;
	}

	public List<Integer> getPositionsRowspans() {
		return positionsRowspans;
	}

	public void setPositionsRowspans(List<Integer> positionsRowspans) {
		this.positionsRowspans = positionsRowspans;
	}

}
