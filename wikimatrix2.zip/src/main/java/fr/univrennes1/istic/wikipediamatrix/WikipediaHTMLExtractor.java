package fr.univrennes1.istic.wikipediamatrix;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;


import au.com.bytecode.opencsv.CSVWriter;

public class WikipediaHTMLExtractor {

	private String BASE_WIKIPEDIA_URL;
	private String outputDirHtml;
	private String outputDirWikitext;
	private File file;
	
	private CSVWriter csvWriter;

	private static final Logger logger = LogManager.getLogger(WikipediaHTMLExtractor.class);

	public WikipediaHTMLExtractor(String BASE_WIKIPEDIA_URL, String outputDirHtml, String outputDirWikitext, File file) {
		this.BASE_WIKIPEDIA_URL = BASE_WIKIPEDIA_URL;
		this.outputDirHtml = outputDirHtml;
		this.outputDirWikitext = outputDirWikitext;
		this.file = file;
	}

	/** M�thode permettant d'extraire le contenu de toutes les wikitables pr�sentes sur l'url param�trique.
	 * Renvoie un objet RetourExtraction, qui contient la liste des tableaux (utile pour les tests unitaires)
	 * et si la lecture est un �chec (utile pour les statistiques de fin de traitement). **/
	public RetourExtraction extraire(String url) throws IOException {
	   List<Element> listeRetour = new ArrayList<Element>();
	   boolean enEchec = false;
	   logger.debug("D�but de l'extraction");
	   try {
		   String wurl = BASE_WIKIPEDIA_URL + url;
		   logger.debug("On extrait � pr�sent cette page : " + wurl);
		   Document doc = Jsoup.connect(wurl).get();

	       // On it�re sur chaque tableau de la page.
	       List<Element> tables = doc.select("table.wikitable");
	       logger.debug("Il y a " + String.valueOf(tables.size()) + " tableaux dans cette page.");
	       for (int i = 0; i < tables.size(); i++ ) {
	    	   Element table = tables.get(i);
	    	   traiterTableau(table, url, i);
	    	   listeRetour.add(table);
	       }
	   } catch(Exception e) {
		   logger.warn("Cette url n'est pas accessible. Le traitement va l'ignorer et se poursuivre.");
		   enEchec = true;
	   }
	   logger.debug("Fin de l'extraction");
       return new RetourExtraction(listeRetour, enEchec);
	}

	/** M�thode permettant de traiter un tableau, en trois temps : d'abord en initialisation le fichier
	 * csv, ensuite �crivant les headers, et enfin en �crivant les lignes. **/
	public void traiterTableau(Element table, String url, int i) throws IOException {
		logger.debug("D�but du traitement du tableau n� " + String.valueOf(i + 1));

		try {
			// On initialise le fichier csv.
			String csvFileName = mkCSVFileName(url, i + 1);
			File csvFile = new File(outputDirWikitext + csvFileName);
			logger.debug("Le fichier est cr�� ici : " + outputDirWikitext + csvFileName);
			FileWriter fileWriter = new FileWriter(csvFile, StandardCharsets.UTF_8);
			csvWriter = new CSVWriter(fileWriter, ';');
	
			// On initialise la map de rowspans et les lignes
			Map<Integer, Rowspan> rowspans = new HashMap<Integer, Rowspan>();
			Elements lignes = table.select("tr");
			logger.debug("Il y a " + String.valueOf(lignes.size()) + " lignes dans ce tableau, en-t�tes comprises.");
	
			// On traite les headers
			int nombreHeaders = traiterHeaders(lignes);

			// On cr�e les lignes
			for (int compteur = nombreHeaders; compteur < lignes.size(); compteur ++) {
				Element ligne = lignes.get(compteur);
				logger.debug("on traite la ligne : " + compteur);
				rowspans = traiterLigne(rowspans, ligne);
			}
	        csvWriter.close();
		} catch(Exception e) {
			logger.warn("Une erreur est survenue durant le traitement de ce tableau.");
		}
		logger.debug("Fin du traitement du tableau n� " + String.valueOf(i + 1) + ".");
	}

	/** M�thode permettant de traiter les headers, et renvoyant le nombre de headers trait�s. **/
	public int traiterHeaders(Elements lignes) {
		List<Element> headers = new ArrayList<Element>();
		int nombreHeaders = 0; 
		while (isHeader(lignes.get(nombreHeaders))) {
			headers.add(lignes.get(nombreHeaders));
			nombreHeaders ++;
		}
		if (nombreHeaders > 0) {
			ecrireHeaders(headers);
		}
		return nombreHeaders;
	}
	
	/** Cette m�thode permet d'�crire la ou les lignes de headers. On �met l'hypoth�se qu'il y a, pour 
	 * les tableaux auxquels elle s'applique (c'est-�-dire les tableaux ayant au moins une ligne de headers),
	 * exactement une ou deux lignes de headers. Dans tous les cas, on n'�crit dans le csv qu'une seule 
	 * ligne de headers, car m�me lorsqu'il y en avait deux dans la wikitable, le v�ritable en-t�te r�sultait
	 * d'une fusion des deux lignes d'en-t�tes de la wikitable. **/
	public void ecrireHeaders(List<Element> headers) {
		// S'il n'y a qu'une seule ligne de headers : on appelle la m�thode traiterUnSeulHeader, et
		// on �crit dans le csv la ligne qu'elle renvoie.
		if (headers.size() == 1) {
			List<String> listeHeaders1 = traiterUnSeulHeader(headers).getListeHeaders();
			csvWriter.writeNext(transformerListeEnTableau(listeHeaders1));
			// Sinon, c'est qu'il y a deux headers, et dans ce cas on appelle la m�thode traiterDeuxHeaders,
			// puis on �crit dans le csv la ligne qu'elle renvoie. Une �volution de l'application consisterai
			// � distinguer les cas o� il y a deux lignes de headers et les cas o� il y en a plus.
		} else {
			List<String> listeHeaders2 = traiterDeuxHeaders(headers);
			csvWriter.writeNext(transformerListeEnTableau(listeHeaders2));
		}
	}

	/** M�thode permettant d'�crire les en-t�tes lorsqu'il n'y avait qu'une seule ligne d'en-t�te 
	 * dans la wikitable. Renvoie un objet RetourTraiterUnSeulHeader, constitu� d'une liste contenant
	 * les en-t�tes sous forme de String, et d'une liste des positions des �ventuels rowspans
	 * (m�thode con�ue pour traiter rowspans et colspans). **/
	public RetourTraiterUnSeulHeader traiterUnSeulHeader(List<Element> headers) {
		// On initialise les r�sultats.
		List<String> listeHeaders = new ArrayList<String>();
		List<Integer> positionsRowspans = new ArrayList<Integer>();
		// On parcourt la liste des cellules.
		Elements cellules = headers.get(0).children();
		// On initialise, pour parcourir la liste de cellules, un indice  qui prenne en compte la quantit�
		// de colspans.
		int k = 0;
		for (int i = 0; i < cellules.size(); i++) {
			Element cellule = cellules.get(i);
			// Si cette cellule poss�de un colspan, on l'�crit autant de fois que la taille de ce
			// colspan.
			if (cellule.hasAttr("colspan")) {
				for (int j = 0; j < Integer.valueOf(cellule.attr("colspan")); j++) {
					listeHeaders.add(cellule.text());
				}
				k += Integer.valueOf(cellule.attr("colspan"));
			} else {
				listeHeaders.add(cellule.text());
				k += 1;
			}
			// Si cette cellule poss�de un rowspan, on enregistre l'information (elle sera utile
			// pour l'�criture d'une �ventuelle deuxi�me ligne de headers).
			if (cellule.hasAttr("rowspan")) {
				positionsRowspans.add(Integer.valueOf(k - 1));
			}

		}
		return new RetourTraiterUnSeulHeader(listeHeaders, positionsRowspans);
	}

	/** M�thode permettant de traiter les en-t�tes des wikitables pr�sentant des en-t�tes sur deux
	 * lignes, avec la premi�re contenant �ventuellement des rowspans et des colspans. Renvoie une 
	 * seule liste d'en-t�tes sous forme de String, car lorsqu'il y a deux lignes d'en-t�tes dans une
	 * wikitable, la v�ritable en-t�te d'une colonne est constitu�e par la concat�nation des deux
	 * en-t�tes. **/
	public List<String> traiterDeuxHeaders(List<Element> headers) {
		// On r�cup�re les informations issues du traitement de la premi�re ligne.
		RetourTraiterUnSeulHeader retourTraiterUnSeulHeader = traiterUnSeulHeader(headers);
		List<String> listeHeaders1 = retourTraiterUnSeulHeader.getListeHeaders();
		List<Integer> positionsRowspans = retourTraiterUnSeulHeader.getPositionsRowspans();
		// On initialise le r�sultat.
		List<String> listeHeaders2 = new ArrayList<String>();
		// On cr�e un indice secondaire qui parcourra la liste des cellules de la seconde ligne d'en-t�te
		// en m�me temps que l'indice principal, mais avec un d�calage correspondant au nombre de rowspans
		// trait�s jusque l�.
		int j = 0;
		Elements cellules2 = headers.get(1).children();
		for (int i = 0; i < listeHeaders1.size(); i++) {
			// On traite le cas o� il y avait des rowspans dans la ligne pr�c�dente : alors on copie 
			// simplement le contenu de la cellule � rowspan, et on retarde l'incide secondaire.
			if (positionsRowspans.contains(Integer.valueOf(i))) {
				listeHeaders2.add(listeHeaders1.get(i));
				j -= 1;
			} else {
				listeHeaders2.add(listeHeaders1.get(i) + " " + cellules2.get(j).text());
			}
			j += 1;
		}
		return listeHeaders2;
	}

	/** Cette m�thode permet de traiter une ligne. Un soin particulier a �t� apport� � la gestion des rowspans.
	 * Cette m�thode prend en param�tre une map <Integer, Rowspan>, et retourne une map du m�me type, ce qui
	 * lui permet de traiter les rowspans que lui ont l�gu�s les lignes pr�c�dentes, et d'envoyer aux lignes 
	 * cette map, modifi�e et potentiellement compl�t�es des nouveaux rowspans dont elle fait l'objet. **/
	public Map<Integer, Rowspan> traiterLigne(Map<Integer, Rowspan> mapRowspans, Element ligne) {
		Elements cellules = ligne.children();

		Map<Integer, Rowspan> retour = new HashMap<Integer, Rowspan>();
		Rowspan rowspan = null;

		int compteurAnciensRowspansTraites = 0;
		int tailleTotale = getNombreCellulesDansLigne(mapRowspans, ligne);

		// Pour compl�ter la liste nouvellement cr��e avec les �ventuels rowspans r�siduels l�gu�s
		// par les lignes pr�c�dentes, on parcourt la map rowspans. Lorsqu'on trouve un Rowspan � la 
		// position Integer, on ins�re une nouvelle cellule dans la liste des cellules nouvellement 
		// cr��e, � la position Integer.
		String listeCellules[] = new String[tailleTotale];
		for (int k = 0; k < tailleTotale; k++) {
			// On traite d'abord les cas o� la cellule est sous le coup d'un ancien rowspan.
			if (mapRowspans.containsKey(Integer.valueOf(k))) {
				rowspan = mapRowspans.get(k);
				listeCellules[k] = rowspan.getTexte();
				// Et on n'oublie pas de mettre � jour la map, en d�cr�mentant l'attribut rowspanResiduel
				// du rowspan courant (voire supprimant ce rowspan s'il devient nul).
				if (rowspan.getRowspanResiduel() > 1) {
					rowspan.setRowspanResiduel(rowspan.getRowspanResiduel() - 1);
					retour.put(k, rowspan);
				}
				compteurAnciensRowspansTraites += 1;
			} else {
				// Si la cellule trait�e n'est pas sous le coup d'un ancien rowspan, on fait le test :
				// poss�de-t-elle un colspan (nous faisons l'hypoth�se qu'un colspan et un rowspan ne 
				// peuvent pas se trouver dans une m�me cellule) ? Si oui, on �crit cette cellule dans 
				// la liste de r�sultats autant de fois que la valeur dudit colspan.
				Element cellule = cellules.get(k - compteurAnciensRowspansTraites);
				if (cellule.hasAttr("colspan")) {
					for (int l = 0; l < Integer.valueOf(cellule.attr("colspan")); l++) {
						listeCellules[k + l] = cellule.text();
					}
					k += Integer.valueOf(cellule.attr("colspan")) - 1;
				} else {
					listeCellules[k] = cellule.text();
				}
				// Si la cellule contient un rowspan, on le cr�e et on l'ajoute � la map.
				if (cellule.hasAttr("rowspan")) {
					rowspan = new Rowspan(Integer.valueOf(cellule.attr("rowspan")) - Integer.valueOf(1), cellule.text());
					retour.put(k, rowspan);
				}
			}
		}
		csvWriter.writeNext(listeCellules);
		return retour;
	}

	
	// ***************************************** METHODES TECHNIQUES *******************************************
	
	
	/** M�thode technique permettant de compter le nombre de colonnes dans un tableau, c'est-�-dire le 
	 * nombre de "vraies" cellules dans une ligne, c'est-�-dire en prenant en compte les rowspans pr�c�dents
	 * (une ligne pr�c�d�e d'une ligne pr�sentant n rowspans contient formellement n cellules de moins) 
	 * ainsi que les colspans. **/
	public int getNombreCellulesDansLigne(Map<Integer, Rowspan> mapRowspans, Element ligne) {
		int resultat = mapRowspans.size();
		for (int i = 0; i < ligne.children().size(); i++) {
			if (ligne.children().get(i).hasAttr("colspan")) {
				resultat += Integer.valueOf(ligne.children().get(i).attr("colspan"));
			} else {
				resultat += 1;
			}
		}
		return resultat;
	}

	public int getNombreCellulesDansLigne(List<Element> headers) {
		int resultat = 0;
		for (int i = 0; i < headers.size(); i++) {
			if (headers.get(i).hasAttr("colspan")) {
				resultat += Integer.valueOf(headers.get(i).attr("colspans"));
			} else {
				resultat += 1;
			}
		}
		return resultat;
		
	}

	/** M�thode renvoyant true si la ligne en question est une ligne d'en-t�tes (c-�-d exclusivement compos�e
	 * d'�l�ments th), false sinon. **/
	public boolean isHeader(Element ligne) {
		for (Element element : ligne.children()) {
			if (!element.is("th")) {
				return false;
			}
		}
		return true;
	}

	/** M�thode renvoyant le nom du fichier csv � cr�er � partir de l'url de la page d'origine
	 * et du rang du tableau dans celle-ci. **/
	public String mkCSVFileName(String url, int n) {
		return url.trim() + "-" + n + ".csv";
	}

	/** M�thode technique permettant de transformer une liste de String en tableaux de String
	 * (utile notamment car le csvWriter prend des tableaux en param�tres).
	 * **/
	public String[] transformerListeEnTableau(List<String> listeHeaders) {
		String[] resultat = new String[listeHeaders.size()];
		for (int i = 0; i < listeHeaders.size(); i++) {
			resultat[i] = listeHeaders.get(i);
		}
		return resultat;
	}


	// ********************************************* ACCESSEURS ***********************************************


	public String getBASE_WIKIPEDIA_URL() {
		return BASE_WIKIPEDIA_URL;
	}

	public void setBASE_WIKIPEDIA_URL(String bASE_WIKIPEDIA_URL) {
		BASE_WIKIPEDIA_URL = bASE_WIKIPEDIA_URL;
	}

	public String getOutputDirHtml() {
		return outputDirHtml;
	}

	public void setOutputDirHtml(String outputDirHtml) {
		this.outputDirHtml = outputDirHtml;
	}

	public String getOutputDirWikitext() {
		return outputDirWikitext;
	}

	public void setOutputDirWikitext(String outputDirWikitext) {
		this.outputDirWikitext = outputDirWikitext;
	}

	public File getFile() {
		return file;
	}

	public void setFile(File file) {
		this.file = file;
	}

}